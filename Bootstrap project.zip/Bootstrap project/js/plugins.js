// Navbar transparent to Solid //
function checkScroll() {
        if($(window).scrollTop() >= 300){
            $('.navbar').addClass('solid');
        } else {
            $('.navbar').removeClass('solid');
        }
}
//////////////////////////////////

// when navbar is toggled //
// when berger menu is open at top of the page the background is not solid so we solve the problem with these codes below //
$(document).ready(function () {
    checkScroll();
    $(window).scroll(checkScroll);
    $('.navbar-toggler').click(function(){
        if($(window).scrollTop() <= 300){
            $('nav.navbar').toggleClass('solid-toggle');
        }
    });
});
/////////////////////////////////////

// smooth scroll when we click on links on the navbar//
$(document).on('click', 'a[href^="#"]', function(event){
    event.preventDefault();
    // these two lines would make the navbar disappear in small screen. if you inspect the code you see them toggle on and off //
    $('.navbar-toggler').addClass('collapsed');
    $('#nav').removeClass('show'); //when you click on the link on the berger menu it is going to close the menu //
    setTimeout(function(){
        $('nav.navbar').removeClass('solid-toggle'); //if you click on the home when you are at the bottom the nav background would not fade so you have to remove solid toggle class still it would fade out and in until you set a timeout (delay) //
    } , 300);

    // it would not navigate you to the links until you make it animate //
    $('html , body').animate({
        scrollTop: $($.attr(this, 'href')).offset().top
    } , 2000); //the number is the interval based on 1000//
});

// Lightbox image gallery setting based on the developer site//
$(document).ready(function(){
    lightbox.option({
        // اولین آپشن فقط برای دفعه اول اجرا میشود که بر حسب میلی ثانیه است
        'resizeDuration': 500,
        'wrapAround': true,
        'imageFadeDuration': 600
        // آپشن سوم هم فاصله بین تعویض عکسها است
    })
})
////////////////////////////////////////////////////

// team Carousel//
$(document).ready(function(){ 
    $('#team-carousel').owlCarousel({ //یه کد برداشته شده از وبسایت آفیشال کاروسل
        autoplay: true, //set to false to turn off autoplay and only use nav
        autoplayHoverPause: true, //set to false to prevent pausing on hover
        loop: true, //set to false to stop carousel after all slides shown
        autoplayTimeout: 7000, //time between transitions
        smartSpeed: 1200, //transition speed
        dotsSpeed: 1000, //transition speed when using dots/buttons
        responsive : { //set number of items shown per screen width
            0 : {
                items: 1 //0px width and up display 1 item
            },
            768 : {
                items: 2 //768px width and up display 2 items
            },
            992 : {
                items: 3 //992px width and up display 3 items
            }
        }
    });
  });
///////////////////////////////////////////////////

// COUNTER up for Skills//
$(document).ready(function () {

    $('.counter').counterUp({
        delay: 10,
        time: 10000,
    });
});
///////////////////////////////////////////////////

// clients Carousel //
$(document).ready(function(){ 
    $('#clients-carousel').owlCarousel({ //یه کد برداشته شده از وبسایت آفیشال کاروسل
        autoplay: true, //set to false to turn off autoplay and only use nav
        autoplayHoverPause: true, //set to false to prevent pausing on hover
        loop: true, //set to false to stop carousel after all slides shown
        autoplayTimeout: 7000, //time between transitions
        smartSpeed: 1600, //transition speed
        dotsSpeed: 1000, //transition speed when using dots/buttons
        responsive : { //set number of items shown per screen width
            0 : {
                items: 1 //0px width and up display 1 item
            },
            768 : {
                items: 2 //768px width and up display 2 items
            }
        }
    });
  });
//////////////////////////////////////////////////

// scroll up arrow //
$(document).ready(function(){
    $(window).scroll(function (){
        if ($(this).scrollTop() > 500) {
            $('.scroll-up').fadeIn();
        } else {
            $('.scroll-up').fadeOut();
        }
    })
});